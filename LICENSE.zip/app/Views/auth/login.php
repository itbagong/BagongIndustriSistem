<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login ERP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body style="font-family: Arial; background:#f4f4f4">

<div style="max-width:420px;margin:60px auto;padding:25px;background:#fff;border-radius:10px">

    <h2 style="text-align:center;margin-bottom:15px">Login ERP</h2>

    <?php if (session()->getFlashdata('error')): ?>
        <div style="color:red;margin-bottom:10px">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif ?>

    <form method="post" action="/login">

        <label>Email</label><br>
        <input type="email" name="email" required
               style="width:100%;padding:10px;margin:5px 0 10px">

        <label>Password</label><br>
        <input type="password" name="password" required
               style="width:100%;padding:10px;margin:5px 0 15px">

        <button type="submit"
                style="width:100%;padding:10px;background:#1f7ae0;color:#fff;border:0;border-radius:6px">
            Login
        </button>

    </form>

</div>

</body>
</html>
