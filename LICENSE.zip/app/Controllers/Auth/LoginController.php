<?php

namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use CodeIgniter\Session\Session;

class LoginController extends BaseController
{
    public function index()
    {
        return view('auth/login');
    }

    public function process()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        // sementara: hardcode user dummy dulu
        $user = [
            'email' => 'admin@example.com',
            'password' => password_hash('123456', PASSWORD_BCRYPT),
            'name' => 'Admin ERP'
        ];

        // validasi sederhana dulu
        if ($email !== $user['email'] || ! password_verify($password, $user['password'])) {
            return redirect()->back()->with('error', 'Email atau password salah');
        }

        session()->set([
            'logged_in' => true,
            'user_name' => $user['name'],
            'user_email' => $user['email']
        ]);

        return redirect()->to('/dashboard');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
