<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth\LoginController::index');
$routes->get('login', 'Auth\LoginController::index');
$routes->post('login', 'Auth\LoginController::process');
$routes->get('logout', 'Auth\LoginController::logout');

$routes->get('dashboard', function () {
    if (! session('logged_in')) {
        return redirect()->to('/login');
    }

    echo "Halo " . session('user_name') . ", kamu berhasil login 🎉";
});
